package com.example.bookdemo.service;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.bookdemo.entity.Book;
import com.example.bookdemo.entity.Subscription;
import com.example.bookdemo.entity.User;
import com.example.bookdemo.repositry.LibraryRepository;

@Service
public class LibraryService {

	@Autowired
	private LibraryRepository libraryRepository;

	@Autowired
	private UserService userService;

	@Autowired
	private BookService bookService;

	public void subscribeBook(Integer bookId, Integer userId) {
		Subscription subscription = new Subscription();
		User user = userService.getById(userId);
		Book book = bookService.getById(bookId);
		subscription.setDateSubscribed(new Date());
		subscription.setBookId(book);
		subscription.setUserId(user);
		this.libraryRepository.save(subscription);

	}

	public void returnBook(Integer bookId, Integer userId) {

		Subscription subscription = new Subscription();
		User user = userService.getById(userId);
		Book book = bookService.getById(bookId);
		subscription.setDateReturned(new Date());
		subscription.setBookId(book);
		subscription.setUserId(user);
		this.libraryRepository.save(subscription);
	}
}
