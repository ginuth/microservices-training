package com.example.bookdemo.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Book {

	@Id
	private Integer id;

	private String name;

	private String author;

	@Column(name = "availablecopies")
	private Integer availableCopies;

	private Integer totalCopies;
	//
	// @OneToMany
	// @JoinColumn(name = "employeeId", referencedColumnName = "id")
	// Set<Address> address;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getAvailableCopies() {
		return availableCopies;
	}

	public void setAvailableCopies(Integer availableCopies) {
		this.availableCopies = availableCopies;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public Integer getTotalCopies() {
		return totalCopies;
	}

	public void setTotalCopies(Integer totalCopies) {
		this.totalCopies = totalCopies;
	}

	// public Set<Address> getAddress() {
	// return address;
	// }
	//
	// public void setAddress(Set<Address> address) {
	// this.address = address;
	// }
	//

}
