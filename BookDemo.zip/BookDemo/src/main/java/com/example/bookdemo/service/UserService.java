package com.example.bookdemo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.bookdemo.entity.User;
import com.example.bookdemo.repositry.UserRepository;

@Service
public class UserService {

	@Autowired
	UserRepository userRepository;

	public Integer add(User user) {

		userRepository.save(user);

		return user.getId();
	}

	public User getById(Integer id) {

		return userRepository.findUserById(id);
	}
}
