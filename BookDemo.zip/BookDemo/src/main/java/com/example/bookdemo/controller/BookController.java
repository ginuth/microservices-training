package com.example.bookdemo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.bookdemo.entity.Book;
import com.example.bookdemo.entity.User;
import com.example.bookdemo.model.SubscriptionRequest;
import com.example.bookdemo.service.BookService;
import com.example.bookdemo.service.LibraryService;
import com.example.bookdemo.service.UserService;

@RestController
@RequestMapping("/books")
public class BookController {

	@Autowired
	BookService bookService;
	@Autowired
	UserService userService;
	@Autowired
	LibraryService libraryService;

	@GetMapping
	public List<Book> getAll() {
		return bookService.getAll();
	}

	@GetMapping("/book/{name}")
	public Book getBookByName(@PathVariable String name) {
		return bookService.getByName(name);
	}

	@GetMapping("/book/{id}")
	public Book getBookById(@PathVariable Integer id) {
		return bookService.getById(id);
	}

	@GetMapping("/book/{author}")
	public Book findBookByAuthor(@PathVariable String author) {
		return bookService.findByAuthor(author);
	}

	@PostMapping("/book")
	public Book addBook(@RequestBody Book book) {

		return bookService.addBook(book);
	}

	@PatchMapping("/book/return")
	public void updateBookOnReturn(@RequestBody SubscriptionRequest subscriptionRequest) {
		libraryService.subscribeBook(subscriptionRequest.getBookId(), subscriptionRequest.getUserId());
		bookService.incrementBookCount(subscriptionRequest.getBookId());
	}

	@PatchMapping("/book/subscribe")
	public void updateBookOnSubscribe(@RequestBody SubscriptionRequest subscriptionRequest) {
		libraryService.returnBook(subscriptionRequest.getBookId(), subscriptionRequest.getUserId());
		bookService.derementBookCount(subscriptionRequest.getBookId());
	}

	@GetMapping("/user/{id}")
	public User getUserById(@PathVariable Integer id) {
		return userService.getById(id);
	}

	@PostMapping("/user")
	public Integer addUser(@RequestBody User user) {

		return userService.add(user);
	}

}
