package com.example.bookdemo.repositry;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.bookdemo.entity.Book;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;

public interface BookRespository extends JpaRepository<Book, Integer> {

	@Query(value = "select * from Book where name = :name", nativeQuery = true)
	Book findBookByName(@Param(value = "name") String name);

	@Query(value = "select * from Book where id = :id", nativeQuery = true)
	Book findBookById(@Param(value = "id") Integer id);

	@Query(value = "select * from Book where author = :author", nativeQuery = true)
	Book findBookByAuthor(@Param(value = "author") String author);

	@Transactional
	@Modifying
	@Query(value = "update Book b set b.availablecopies = ?1 where b.id = ?2", nativeQuery = true)
	void setBookInfoById(Integer availableCopies, Integer bookId);

	List<Book> findAll();
}
