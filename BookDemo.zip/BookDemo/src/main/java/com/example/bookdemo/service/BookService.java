package com.example.bookdemo.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.bookdemo.entity.Book;
import com.example.bookdemo.repositry.BookRespository;

@Service
public class BookService {

	@Autowired
	BookRespository bookRepository;

	public List<Book> getAll() {
		return bookRepository.findAll();
	}

	public Integer add(Book book) {

		bookRepository.save(book);

		return book.getId();
	}

	public Book getByName(String name) {

		return bookRepository.findBookByName(name);
	}

	public Book getById(Integer id) {

		return bookRepository.findBookById(id);
	}

	public Book findByAuthor(String author) {

		return bookRepository.findBookByAuthor(author);
	}

	@Transactional
	public Book addBook(Book user) {

		Book book = bookRepository.saveAndFlush(user);

		return book;
	}

	@Transactional
	public void incrementBookCount(Integer bookId) {
		Book book = bookRepository.findBookById(bookId);
		bookRepository.setBookInfoById(book.getAvailableCopies() + 1, book.getId());
	}

	@Transactional
	public void derementBookCount(Integer bookId) {
		Book book = bookRepository.findBookById(bookId);
		bookRepository.setBookInfoById(book.getAvailableCopies() - 1, book.getId());

	}
}
