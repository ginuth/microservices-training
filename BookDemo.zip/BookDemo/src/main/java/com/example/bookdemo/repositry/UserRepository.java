package com.example.bookdemo.repositry;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.bookdemo.entity.User;

@Repository
public interface UserRepository extends CrudRepository<User, String> {

	@Query(value = "select * from User where id = :id", nativeQuery = true)
	User findUserById(@Param(value = "id") Integer id);
}
