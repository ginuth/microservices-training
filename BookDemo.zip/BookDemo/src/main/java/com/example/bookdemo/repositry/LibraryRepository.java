package com.example.bookdemo.repositry;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.bookdemo.entity.Subscription;

@Repository
public interface LibraryRepository extends CrudRepository<Subscription, String> {

}
