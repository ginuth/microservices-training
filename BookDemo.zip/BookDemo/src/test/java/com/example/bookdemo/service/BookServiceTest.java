package com.example.bookdemo.service;

import static org.junit.Assert.*;

import org.junit.Test;

public class BookServiceTest {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
