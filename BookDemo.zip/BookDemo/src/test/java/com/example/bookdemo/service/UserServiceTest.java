package com.example.bookdemo.service;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import com.example.bookdemo.entity.User;
import com.example.bookdemo.repositry.UserRepository;


	@ExtendWith(MockitoExtension.class)
	public class UserServiceTest {
		
		@InjectMocks
		private UserService userService;
		
		@Mock
		private UserRepository userRepository;
		
		private User user1;
		
		@BeforeEach
		public void setup() {
			
			user1 = new User();
			user1.setId(101);
			user1.setFirstName("James");
			user1.setLastName("Anderson");
		}
		
		@Test
		public void getUserByIdShouldReturnUser() {
			
			Mockito.when(userRepository.findUserById(Mockito.eq(101))).thenReturn(user1);
			
			User returnedUser = userService.getById(101);
			
			assertEquals(101, returnedUser.getId());
		}
		
}
