package com.example.bookdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
