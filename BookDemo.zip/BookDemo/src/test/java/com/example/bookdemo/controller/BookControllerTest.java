package com.example.bookdemo.controller;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.example.bookdemo.service.BookService;
import com.example.bookdemo.service.LibraryService;
import com.example.bookdemo.service.UserService;

@ExtendWith(MockitoExtension.class)
public class BookControllerTest {

	@Mock
	BookService bookService;
	@Mock
	UserService userService;
	@Mock
	LibraryService libraryService;
	
	@InjectMocks
	private BookController bookControler;
	
	@Autowired
	private MockMvc mockMvc;
	
	@BeforeEach
	public void setup() {
		mockMvc = MockMvcBuilders.standaloneSetup(bookControler).build();
	}
	
	@Test
	public void getBookShouldReturnStatusIsOk() throws Exception {
		
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/books").accept(MediaType.APPLICATION_JSON);

		mockMvc.perform(requestBuilder).andExpect(MockMvcResultMatchers.status().isOk());
	
		Mockito.verify(bookService, Mockito.times(1)).getAll();
	}
}
